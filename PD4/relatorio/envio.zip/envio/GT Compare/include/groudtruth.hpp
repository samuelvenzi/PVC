#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <opencv2/opencv.hpp>
#include <fstream>

double gtcompare(cv::Mat gt_img, cv::Mat out_img);